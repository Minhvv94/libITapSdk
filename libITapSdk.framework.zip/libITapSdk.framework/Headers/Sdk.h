//
//  Sdk.h
//  SdkFrameworkDemo
//
//  Created by Minh Vu on 24/08/2022.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface Sdk : NSObject
- (void) printSdk;

@end

NS_ASSUME_NONNULL_END
