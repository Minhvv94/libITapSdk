//
//  libITapSdk.h
//  libITapSdk
//
//  Created by Minh Vu on 25/08/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for libITapSdk.
FOUNDATION_EXPORT double libITapSdkVersionNumber;

//! Project version string for libITapSdk.
FOUNDATION_EXPORT const unsigned char libITapSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <libITapSdk/PublicHeader.h>


